export default {
  constant: {
    PAGE_WIDTH: 1920,
    PAGE_HEIGHT: 1080
  }
};
